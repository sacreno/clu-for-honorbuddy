﻿#region

using System.Drawing;
using Styx.Helpers;

#endregion

using Styx.Common;

namespace PvPRogue
{
    public static class Log
    {
        public static Color LogColour = Color.Cyan;
        public static string PreText = "[PvPRogue] ";

        public static void Write(string Value, params object[] args)
        {
            Value = string.Format(Value, args);

            Logging.Write(PreText + Value);
            Logging.Write(PreText + Value);
        }

        public static void WriteDebug(string Value, params object[] args)
        {
            Value = string.Format(Value, args);

            Logging.Write(PreText + Value);
        }
    }
}