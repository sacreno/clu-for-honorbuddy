﻿#region

using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using Styx.Helpers;

#endregion

using Styx.Common;

namespace PvPRogue.Managers
{
    internal static class SpeedDebug
    {
        private static List<int> PulseLength = new List<int>();
        private static int Over500;

        internal static void Pulse(int MS)
        {
            PulseLength.Add(MS);

            if (PulseLength.Count() > 1000)
            {
                int Highest = (from CurMS in PulseLength
                               orderby CurMS descending
                               select CurMS).FirstOrDefault();

                int Lowest = (from CurMS in PulseLength
                              orderby CurMS ascending
                              select CurMS).FirstOrDefault();


                PulseLength = (from CurMS in PulseLength
                               orderby CurMS descending
                               select CurMS).ToList();

                int Total = 0;
                int Average = 0;
                int Count = 0;
                foreach (int CurInt in PulseLength)
                {
                    if (Count <= 10)
                    {
                        Logging.Write("[PvPRogue Debug] - {0} Highest: {1}", Count, CurInt);
                        Logging.Write("[PvPRogue Debug] - {0} Highest: {1}", Count, CurInt);
                        Count++;
                    }

                    Total += CurInt;
                    if (CurInt >= 500) Over500++;
                }
                Average = Total/PulseLength.Count();


                Logging.Write("[PvPRogue Debug] - Highest: {0}  Lowest: {1}  Average: {2}  Over 500MS: {3}",
                              Highest, Lowest, Average, Over500);
                Logging.Write("[PvPRogue Debug] - Highest: {0}  Lowest: {1}  Average: {2}  Over 500MS: {3}",
                                   Highest, Lowest, Average, Over500);


                PulseLength.Clear();
                Over500 = 0;
            }
        }
    }
}