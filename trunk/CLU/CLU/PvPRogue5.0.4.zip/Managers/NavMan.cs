﻿#region

using System.Linq;
using Styx;
using Styx.Helpers;
using Styx.Pathing;
using Styx.Plugins;
using Styx.WoWInternals.WoWObjects;

#endregion

namespace PvPRogue.Managers
{
    public static class NavMan
    {
        public static bool IsGlueEnabled
        {
            get
            {
                int PluginCount = (from MyPlugin in PluginManager.Plugins
                                   where MyPlugin.Name == "Glue" && MyPlugin.Enabled
                                   select MyPlugin).Count();

                if (PluginCount >= 1)
                    return true;

                return false;
            }
        }

        public static void MoveBehind(WoWUnit Unit)
        {
            // Movement Checks
            if (IsGlueEnabled && Unit.Distance < 10) return;
            if (!ClassSettings._Instance.GeneralMovement) return;


            WoWPoint BehindLocation = WoWMathHelper.CalculatePointBehind(Unit.Location, Unit.Rotation, 1.7f);
            Navigator.MoveTo(BehindLocation);
        }
    }
}