﻿#region

using System.Linq;
using PvPRogue.Utils;
using Styx;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

#endregion

namespace PvPRogue.Helpers
{
    internal static class StealthSap
    {
        internal static void Pulse()
        {
            if (StyxWoW.Me.IsActuallyInCombat) return;
            if (!StyxWoW.Me.IsStealthed) return;
            if (!SafeChecks.CombatReady) return;

            WoWUnit SapThisFuck = (from Enemys in ObjectManager.GetObjectsOfType<WoWPlayer>(true, false)
                                   where Enemys.IsStealthed &&
                                         Enemys.Distance <= 10 &&
                                         !Enemys.IsFriendly &&
                                         !Enemys.HasAura("Sap")
                                   select Enemys).FirstOrDefault();

            if (SapThisFuck == null) return;

            Spell.Cast("Sap", SapThisFuck);
        }
    }
}