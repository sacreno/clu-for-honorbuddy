﻿#region

using PvPRogue.Spec.General;
using PvPRogue.Spec.Subtlety.Spells;
using PvPRogue.Utils;
using Styx;

#endregion

namespace PvPRogue.Spec.Subtlety
{
    public static class Combat
    {
        public static string _LastMove;

        public static void pulse()
        {
            if (!SafeChecks.CombatReady) return;

            // Auto Attack
            if (AutoAttack.CanRun)
            {
                if (AutoAttack.Run()) return;
            }

            // If target is running, we need to chase!
            if (Vanish.CanRun)
            {
                Vanish.Run();
            } // Used for -> Vanish -> Shadow Step -> Ambush
            if (Shadowstep.CanRun)
            {
                if (Shadowstep.Run()) return;
            }
            //if (Spells.DeadlyThrow.CanRun) { if (Spells.DeadlyThrow.Run()) return; }
            if (Sprint.CanRun)
            {
                if (Sprint.Run()) return;
            }
            //if (Spells.Throw.CanRun) { if (Spells.Throw.Run()) return; } 

            // Our main moves!
            if (ShadowDance.CanRun)
            {
                if (ShadowDance.EnergySave()) return;
            }
            if (ShadowDance.CanRun)
            {
                if (ShadowDance.Run()) return;
            }
            if (Ambush.CanRun)
            {
                if (Ambush.Run()) return;
            }

            // Defensives
            if (Evasion.CanRun)
            {
                if (Evasion.Run()) return;
            }
            if (Kick.CanRun)
            {
                if (Kick.Run()) return;
            }
            if (CombatReadiness.CanRun)
            {
                if (CombatReadiness.Run()) return;
            }
            if (SmokeBombOffensive.CanRun)
            {
                if (SmokeBombOffensive.Run()) return;
            }
            if (CloakOfShadows.CanRun)
            {
                if (CloakOfShadows.Run()) return;
            }
            //if (Spells.Blind.IfCanRun()) return;

            // Special Moves
            //if (Spells.Shiv.CanRun) { if (Spells.Shiv.Run()) return; }
            if (Dismantle.CanRun)
            {
                if (Dismantle.Run()) return;
            }
            if (Redirect.CanRun)
            {
                if (Redirect.Run()) return;
            }
            //if (Spells.SmokeBombOffensive.CanRun) { if (Spells.SmokeBombOffensive.Run()) return; }
            if (Preparation.CanRun)
            {
                if (Preparation.Run()) return;
            }

            // Finishing moves.
            if (Recuperate.CanRun)
            {
                if (Recuperate.Run()) return;
            }
            if (SliceandDice.CanRun)
            {
                if (SliceandDice.Run()) return;
            }
            if (KidneyShot.CanRun)
            {
                if (KidneyShot.Run()) return;
            }
            if (Eviscerate.CanRun)
            {
                if (Eviscerate.Run()) return;
            }

            // Other stuff
            if (FanofKnives.CanRun)
            {
                if (FanofKnives.Run()) return;
            }

            // if we are not close enough do nothing
            if (!StyxWoW.Me.CurrentTarget.IsWithinMeleeRange) return;

            Spell.Cast(MainMove.GetName, StyxWoW.Me.CurrentTarget);
        }
    }
}