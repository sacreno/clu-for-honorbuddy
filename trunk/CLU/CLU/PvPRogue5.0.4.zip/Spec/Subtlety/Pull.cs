﻿#region

using Styx;

#endregion

namespace PvPRogue.Spec.Subtlety
{
    public static class Pull
    {
        /// <summary>
        ///   Gets the spellname for the opener
        /// </summary>
        /// <returns> SpellName </returns>
        public static string OpenerName
        {
            get
            {
                // Frame lock it, as we are calling CanCast.
                using (StyxWoW.Memory.AcquireFrame())
                {
                    // Garrote
                    if (ClassSettings._Instance.SubtletyOpener == eSubOpener.Garrote)
                    {
                        if (Spell.HasCanSpell("Garrote"))
                            return "Garrote";
                    }

                    // Last resort is ambush
                    // if they dont have this, they seriously need to quit life.
                    return "Ambush";
                }
            }
        }

        public static void Pulse()
        {
            // Lets open!
            if (Spell.HasCanSpell("Shadowstep") && ClassSettings._Instance.PVEStep)
                Spell.Cast("Shadowstep", StyxWoW.Me.CurrentTarget);
            Spell.Cast(OpenerName, StyxWoW.Me.CurrentTarget);
        }
    }
}