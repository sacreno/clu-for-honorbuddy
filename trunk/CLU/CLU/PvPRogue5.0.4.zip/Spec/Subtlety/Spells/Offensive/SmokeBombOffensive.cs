﻿#region

using PvPRogue.Helpers;
using Styx;

#endregion

namespace PvPRogue.Spec.Subtlety.Spells
{
    public static class SmokeBombOffensive
    {
        public static bool CanRun
        {
            get
            {
                if (
                    BGHealers._Instance.IsHealer(StyxWoW.Me.CurrentTarget)
                    ) return true;

                return false;
            }
        }

        public static bool Run()
        {
            Combat._LastMove = "Smoke Bomb";
            return Spell.Cast("Smoke Bomb");
        }
    }
}