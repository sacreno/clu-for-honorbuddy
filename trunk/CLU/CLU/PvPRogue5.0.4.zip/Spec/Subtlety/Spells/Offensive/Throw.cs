﻿#region

using PvPRogue.Utils;
using Styx;
using Styx.WoWInternals.WoWObjects;

#endregion

namespace PvPRogue.Spec.Subtlety.Spells
{
    internal class Throw
    {
        public static bool CanRun
        {
            get
            {
                WoWUnit Target = StyxWoW.Me.CurrentTarget;

                if (PlayerFlee.IsFleeing &&
                    Target.Distance < 30 &&
                    StyxWoW.Me.Inventory.Equipped.Ranged.IsThrownWeapon &&
                    !Spell.HasCanSpell("Shadowstep") &&
                    !Spell.HasCanSpell("Sprint") &&
                    StyxWoW.Me.CurrentTarget.InLineOfSpellSight &&
                    !Spell.HasMyAura("Crippling Poison", Target)
                    ) return true;

                return false;
            }
        }

        public static bool Run()
        {
            Combat._LastMove = "Throw";
            return Spell.Cast("Throw", StyxWoW.Me.CurrentTarget);
        }
    }
}