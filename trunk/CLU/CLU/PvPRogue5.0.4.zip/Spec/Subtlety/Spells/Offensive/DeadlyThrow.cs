﻿#region

using PvPRogue.Utils;
using Styx;

#endregion

namespace PvPRogue.Spec.Subtlety.Spells
{
    internal class DeadlyThrow
    {
        public static bool CanRun
        {
            get
            {
                if (
                    PlayerFlee.IsFleeing &&
                    StyxWoW.Me.CurrentTarget.Distance < 30 &&
                    StyxWoW.Me.ComboPoints >= 1 &&
                    StyxWoW.Me.Inventory.Equipped.Ranged.IsThrownWeapon &&
                    !Spell.HasCanSpell("Shadowstep") &&
                    !Spell.HasCanSpell("Sprint") &&
                    StyxWoW.Me.CurrentTarget.InLineOfSpellSight
                    ) return true;

                return false;
            }
        }

        public static bool Run()
        {
            Combat._LastMove = "Deadly Throw";
            return Spell.Cast("Deadly Throw", StyxWoW.Me.CurrentTarget);
        }
    }
}