﻿#region

using Styx;

#endregion

namespace PvPRogue.Spec.Subtlety.Spells
{
    public static class Shiv
    {
        public static bool CanRun
        {
            get
            {
                // Make sure we have the spell
                if (!StyxWoW.Me.CurrentTarget.IsWithinMeleeRange) return false;
                if (!Spell.HasCanSpell("Shiv")) return false;


                // Check for target has spells.
                if (StyxWoW.Me.CurrentTarget.HasAura("Enrage")) return true;
                if (StyxWoW.Me.CurrentTarget.HasAura("Wrecking Crew")) return true;
                if (StyxWoW.Me.CurrentTarget.HasAura("Savage Roar")) return true;
                if (StyxWoW.Me.CurrentTarget.HasAura("Unholy Frenzy")) return true;
                if (StyxWoW.Me.CurrentTarget.HasAura("Berserker Rage")) return true;
                if (StyxWoW.Me.CurrentTarget.HasAura("Death Wish")) return true;
                if (StyxWoW.Me.CurrentTarget.HasAura("Owlkin Frenzy")) return true;
                if (StyxWoW.Me.CurrentTarget.HasAura("Bastion of Defense")) return true;

                return false;
            }
        }

        public static bool Run()
        {
            Combat._LastMove = "Shiv";
            return Spell.Cast("Shiv", StyxWoW.Me.CurrentTarget);
        }
    }
}