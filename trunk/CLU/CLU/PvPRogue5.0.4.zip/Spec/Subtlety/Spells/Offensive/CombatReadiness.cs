﻿#region

using PvPRogue.Managers;
using Styx;

#endregion

namespace PvPRogue.Spec.Subtlety.Spells
{
    public static class CombatReadiness
    {
        public static bool CanRun
        {
            get
            {
                if (
                    StyxWoW.Me.HealthPercent < 75 &&
                    PlayerObjects.MeleeTargeting >= 2
                    ) return true;

                return false;
            }
        }

        public static bool Run()
        {
            Combat._LastMove = "Combat Readiness";
            return Spell.Cast("Combat Readiness");
        }
    }
}