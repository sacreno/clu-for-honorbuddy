﻿#region

using PvPRogue.Managers;
using PvPRogue.Spec.Subtlety;

#endregion

namespace PvPRogue.Spec.General
{
    public static class FanofKnives
    {
        public static bool CanRun
        {
            get
            {
                if (PlayerObjects.EnemysAround(8) > ClassSettings._Instance.MovesFOKPeople) return true;

                return false;
            }
        }

        public static bool Run()
        {
            Combat._LastMove = "Fan of Knives";
            return Spell.Cast("Fan of Knives");
        }
    }
}