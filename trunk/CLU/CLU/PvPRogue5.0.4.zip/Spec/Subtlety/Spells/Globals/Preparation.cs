﻿namespace PvPRogue.Spec.Subtlety.Spells
{
    public static class Preparation
    {
        public static bool CanRun
        {
            get
            {
                if (
                    Spell.SpellOnCooldown("Shadowstep") &&
                    Spell.SpellOnCooldown("Sprint")
                    ) return true;

                return false;
            }
        }

        public static bool Run()
        {
            Combat._LastMove = "Preparation";
            return Spell.Cast("Preparation");
        }
    }
}