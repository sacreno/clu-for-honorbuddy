﻿#region

using Styx;

#endregion

namespace PvPRogue.Spec.Subtlety.Spells
{
    public static class Recuperate
    {
        //Recuperate
        public static bool CanRun
        {
            get
            {
                // If we are doing our INIT Pull Burst
                if (
                    ClassSettings._Instance.SubtletyInitBurst &&
                    PvPRogue.PullTimer.ElapsedMilliseconds < PvPRogue.PullLengthMS) return false;

                // High level
                if (
                    StyxWoW.Me.RawComboPoints >= 2 &&
                    Spell.HasMyAuraTimeLeft("Recuperate") < 3000
                    ) return true;


                return false;
            }
        }

        public static bool Run()
        {
            Combat._LastMove = "Recuperate";
            return Spell.Cast("Recuperate");
        }
    }
}