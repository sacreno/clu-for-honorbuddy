﻿#region

using PvPRogue.Utils;

#endregion

namespace PvPRogue.Spec.Subtlety.Spells
{
    internal class Sprint
    {
        public static bool CanRun
        {
            get
            {
                if (PlayerFlee.IsFleeing) return true;

                return false;
            }
        }

        public static bool Run()
        {
            Combat._LastMove = "Sprint";
            return Spell.Cast("Sprint");
        }
    }
}