﻿#region

using Styx;

#endregion

namespace PvPRogue.Spec.Subtlety.Spells
{
    internal class Redirect
    {
        public static bool CanRun
        {
            get
            {
                if (
                    StyxWoW.Me.RawComboPoints != StyxWoW.Me.ComboPoints
                    ) return true;

                return false;
            }
        }

        public static bool Run()
        {
            Combat._LastMove = "Redirect";
            return Spell.Cast("Redirect", StyxWoW.Me.CurrentTarget);
        }
    }
}