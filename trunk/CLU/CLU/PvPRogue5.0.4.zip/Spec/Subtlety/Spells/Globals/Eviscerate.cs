﻿#region

using Styx;

#endregion

namespace PvPRogue.Spec.Subtlety.Spells
{
    internal class Eviscerate
    {
        //Eviscerate 
        public static bool CanRun
        {
            get
            {
                if (ClassSettings._Instance.SubtletyFinisher != eSubFinisher.Eviscerate)
                {
                    if (!Spell.SpellOnCooldown("Kidney Shot"))
                        return false;
                }

                // if we got 5 combo points, well we got to do it anyways
                if (StyxWoW.Me.RawComboPoints >= 5) return true;

                if (
                    StyxWoW.Me.CurrentTarget.IsWithinMeleeRange &&
                    StyxWoW.Me.RawComboPoints > 1 &&
                    Spell.HasMyAuraTimeLeft("Recuperate") > 3000 &&
                    Spell.HasMyAuraTimeLeft("Recuperate") < 4000
                    ) return true;


                return false;
            }
        }


        public static bool CanRunLow
        {
            get
            {
                // if we got 5 combo points, well we got to do it anyways
                if (StyxWoW.Me.RawComboPoints >= 5) return true;


                // High level
                if (
                    StyxWoW.Me.CurrentTarget.HealthPercent < 35 &&
                    StyxWoW.Me.CurrentTarget.IsWithinMeleeRange &&
                    StyxWoW.Me.RawComboPoints >= 4
                    ) return true;


                return false;
            }
        }

        public static bool Run()
        {
            Combat._LastMove = "Eviscerate";
            return Spell.Cast("Eviscerate", StyxWoW.Me.CurrentTarget);
        }
    }
}