﻿#region

using PvPRogue.Helpers;
using Styx.WoWInternals.WoWObjects;

#endregion

namespace PvPRogue.Spec.Subtlety.Spells
{
    public static class Blind
    {
        public static bool IfCanRun()
        {
            if (Spell.SpellOnCooldown("Blind")) return false;

            WoWPlayer HealerTarget = BGHealers._Instance.BestHealer(15);

            if (HealerTarget == null) return false;

            Combat._LastMove = "Blind";
            return Spell.Cast("Blind", HealerTarget);
        }
    }
}