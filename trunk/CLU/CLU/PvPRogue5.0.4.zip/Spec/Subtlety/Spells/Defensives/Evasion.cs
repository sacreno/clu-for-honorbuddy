﻿#region

using Styx;

#endregion

namespace PvPRogue.Spec.Subtlety.Spells
{
    public static class Evasion
    {
        public static bool CanRun
        {
            get
            {
                // If im getting targeted by 2 or more people evasion
                if (
                    StyxWoW.Me.HealthPercent < 65
                    ) return true;

                return false;
            }
        }

        public static bool Run()
        {
            Combat._LastMove = "Evasion";
            return Spell.Cast("Evasion");
        }
    }
}