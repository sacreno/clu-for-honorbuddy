﻿#region

using Styx;
using Styx.Combat.CombatRoutine;

#endregion

namespace PvPRogue.Spec.Subtlety.Spells
{
    public static class Dismantle
    {
        public static bool CanRun
        {
            get
            {
                // Make sure we have the spell
                if (!StyxWoW.Me.CurrentTarget.IsWithinMeleeRange) return false;
                if (!StyxWoW.Me.CurrentTarget.IsPlayer) return false;

                // Class's we want to dismantle
                if (StyxWoW.Me.CurrentTarget.Class == WoWClass.DeathKnight) return true;
                if (StyxWoW.Me.CurrentTarget.Class == WoWClass.Hunter) return true;
                if (StyxWoW.Me.CurrentTarget.Class == WoWClass.Rogue) return true;
                if (StyxWoW.Me.CurrentTarget.Class == WoWClass.Warrior) return true;

                return false;
            }
        }

        public static bool Run()
        {
            Combat._LastMove = "Dismantle";
            return Spell.Cast("Dismantle", StyxWoW.Me.CurrentTarget);
        }
    }
}