﻿#region

using System;
using System.Diagnostics;
using PvPRogue.Helpers;
using PvPRogue.Managers;
using PvPRogue.Utils;
using Styx;
using Styx.Combat.CombatRoutine;
using Styx.CommonBot;
using Styx.CommonBot.Inventory;
using Styx.CommonBot.Routines;
using Styx.Helpers;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

#endregion

namespace PvPRogue
{
    internal class PvPRogue : CombatRoutine
    {
        public static Stopwatch PullTimer = new Stopwatch();
        public static int PullLengthMS = 4000;
        public LocalPlayer Me = ObjectManager.Me;
        public Version version = new Version(4, 1);

        public override string Name
        {
            get { return "PvPRogue" + version; }
        }

        public override WoWClass Class
        {
            get { return WoWClass.Rogue; }
        }

        public override bool WantButton
        {
            get { return true; }
        }

        public override bool NeedRest
        {
            get
            {
                if (StyxWoW.Me.HealthPercent >= ClassSettings._Instance.PVERestAt) return false;
                if (StyxWoW.Me.HasAura("Resurrection Sickness")) return false;
                if (StyxWoW.Me.Dead || StyxWoW.Me.IsGhost ||
                    StyxWoW.Me.IsCasting || StyxWoW.Me.Combat ||
                    StyxWoW.Me.IsSwimming || StyxWoW.Me.HasAura("Food") ||
                    Consumable.GetBestFood(false) == null || Battlegrounds.IsInsideBattleground) return false;

                return true;
            }
        }

        public override void OnButtonPress()
        {
            FormSettings._Instance.Show();
        }


        public override void Initialize()
        {
            FormSettings._Instance = new FormSettings();
            ClassSettings._Instance = new ClassSettings();
            Log.Write("Loading");
            Log.Write("Version: {0}", version);
            Log.Write("Please write in the PvPRogue thread any issues you may be having and ill fix it");
            Managers.Spec.Update();

            // 30 is to fast lmfao, try 23
            TreeRoot.TicksPerSecond = 25;

            // incase they use CombatBot..
            PullTimer.Start();

            if (ClassSettings._Instance.GeneralAlwaysStealthed)
            {
                Log.Write("Always Stealthed Enabled");
                Log.WriteDebug("Disabling Use-Mount");
                CharacterSettings.Instance.UseMount = false;
            }

            Chat.NeutralBattleground += FlagReturn.ChatFilter;
            Chat.AllianceBattleground += FlagReturn.ChatFilter;
            Chat.HordeBattleground += FlagReturn.ChatFilter;

            
        }

        public override void ShutDown()
        {
            // Defaults
            TreeRoot.TicksPerSecond = 15;
            CharacterSettings.Instance.UseMount = true;
        }

        public override void Pull()
        {
            // Quick Target check to see if ok to pull
            if (SafeChecks.TargetSafe == false) return;

            WoWUnit Target = Me.CurrentTarget;

            // We need to face
            if ((!Me.IsSafelyFacing(Target, 90)) && (!Me.IsMoving))
            {
                Target.Face();
            }

            // We need to check if we are behind and have correct distance.
            if ((!Target.IsPlayerBehind) || Target.Distance > 2)
            {
                NavMan.MoveBehind(Target);
            }

            // Wait for full energy b4 we burst
            if (StyxWoW.Me.EnergyPercent != 100) return;

            // Our Pull Timer
            PullTimer.Reset();
            PullTimer.Start();

            // Do what we need to!
            switch (Managers.Spec.CurrentSpec)
            {
                case eSpec.Subtlety:
                    Spec.Subtlety.Pull.Pulse();
                    break;
            }
        }

        public override void Combat()
        {
            var stopWatch = new Stopwatch();
            stopWatch.Start();


            WoWUnit Target = StyxWoW.Me.CurrentTarget;

            if (Target == null) return;

            // Handle behind
            if ((Target.Distance > 2) || (Target.IsPlayer && !Target.MeIsBehind && Target.IsWithinMeleeRange))
            {
                NavMan.MoveBehind(Target);
            }

            if (!Me.IsMoving && !Me.IsSafelyFacing(Target))
            {
                Target.Face();
            }

            // bug with being on a mount
            if (Me.Mounted) Mount.Dismount();

            // Get our Healers
            //Helpers.BGHealers._Instance = new BGHealers();

            // Trinket Manager
            if (Battlegrounds.IsInsideBattleground)
                Trinket.Pulse();

            // Handle Combat
            switch (Managers.Spec.CurrentSpec)
            {
                case eSpec.Subtlety:
                    Spec.Subtlety.Combat.pulse();
                    break;
            }

            stopWatch.Stop();
            SpeedDebug.Pulse((int) stopWatch.ElapsedMilliseconds);
            stopWatch.Reset();
        }

        public override void Pulse()
        {
            StealthSap.Pulse();
        }

        public override void Rest()
        {
            WoWMovement.MoveStop();
            StyxWoW.SleepForLagDuration();
            Styx.CommonBot.Rest.Feed();
            StyxWoW.SleepForLagDuration();
            Spell.Cast("Stealth");

            while (!StyxWoW.Me.Combat && StyxWoW.Me.HealthPercent < 95)
            {
            }
        }

        #region Poison/alwaysstealthed

        public override bool NeedPreCombatBuffs
        {
            get
            {
                if (StyxWoW.Me.IsCasting) return false;
                if (StyxWoW.Me.Combat) return false;
                if (StyxWoW.Me.IsFlying) return false;
                if ((!Poisons.HasMainHandPoison) &&
                    (Poisons.GetPoison(ClassSettings._Instance.SubtletyMainPoison) != null)) return true;
                if ((!Poisons.HasOffHandPoison) &&
                    (Poisons.GetPoison(ClassSettings._Instance.SubtletyOffHandPoison) != null)) return true;
                if ((!Poisons.HasThrownPoison) && (Poisons.GetPoison(ePoison.Crippling) != null) &&
                    (ClassSettings._Instance.GeneralThrownPoison)) return true;

                // Always Stealthed
                if (ClassSettings._Instance.GeneralAlwaysStealthed && Battlegrounds.IsInsideBattleground &&
                    !StyxWoW.Me.HasAura("Stealth")) return true;

                return false;
            }
        }

        public override void PreCombatBuff()
        {
            // Always Stealthed
            if (ClassSettings._Instance.GeneralAlwaysStealthed && !StyxWoW.Me.HasAura("Stealth"))
            {
                if (Spell.HasCanSpell("Stealth"))
                    Spell.Cast("Stealth");
            }


            Poisons.Pulse();
        }

        #endregion

        #region PullBuff

        public override bool NeedPullBuffs
        {
            get
            {
                // We need to be stealthed
                if (SpellManager.CanCast("Stealth") && !Spell.HasAura("Stealth")) return true;

                // If sub, we need to cast premeditation
                if ((Managers.Spec.IsSubtlety)
                    && (Spell.HasCanSpell("Premeditation"))
                    && (!Spell.HasMyAura("Premeditation", StyxWoW.Me.CurrentTarget))
                    && (StyxWoW.Me.CurrentTarget.InLineOfSpellSight)) return true;

                return false;
            }
        }

        public override void PullBuff()
        {
            //////////////////// MOVEMENT ISSUE WITH HB TRYING TO FIX IT ////////////////////
            if (StyxWoW.Me.CurrentTarget.IsWithinMeleeRange == false)
            {
                NavMan.MoveBehind(StyxWoW.Me.CurrentTarget);
            }
            //////////////////// MOVEMENT ISSUE WITH HB TRYING TO FIX IT ////////////////////

            // Stealth
            if (!Spell.HasAura("Stealth"))
            {
                Spell.Cast("Stealth");
                return;
            }

            // if Sub and has a target, and is stealthed, cast Premeditation
            if ((Managers.Spec.IsSubtlety)
                && (StyxWoW.Me.GotTarget)
                && (Spell.HasAura("Stealth")))
            {
                Spell.Cast("Premeditation", StyxWoW.Me.CurrentTarget);
                return;
            }
        }

        #endregion
    }
}